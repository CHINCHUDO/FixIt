﻿namespace FileNameChangeApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.changeFixItDirectoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.changeTargetDirectoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.FixItTxtBox = new System.Windows.Forms.TextBox();
            this.fileListView = new System.Windows.Forms.ListView();
            this.queryBtn = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.prefixTxtBox = new System.Windows.Forms.TextBox();
            this.bookLabel = new System.Windows.Forms.Label();
            this.btnApply = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.targetDirectoryTxtBox = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(28, 28);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1124, 38);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.changeFixItDirectoryToolStripMenuItem,
            this.changeTargetDirectoryToolStripMenuItem,
            this.quitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(56, 34);
            this.fileToolStripMenuItem.Text = "File";
            this.fileToolStripMenuItem.Click += new System.EventHandler(this.fileToolStripMenuItem_Click);
            // 
            // changeFixItDirectoryToolStripMenuItem
            // 
            this.changeFixItDirectoryToolStripMenuItem.Name = "changeFixItDirectoryToolStripMenuItem";
            this.changeFixItDirectoryToolStripMenuItem.Size = new System.Drawing.Size(328, 34);
            this.changeFixItDirectoryToolStripMenuItem.Text = "Change FixIt Directory";
            this.changeFixItDirectoryToolStripMenuItem.Click += new System.EventHandler(this.changeFixItDirectoryToolStripMenuItem_Click);
            // 
            // changeTargetDirectoryToolStripMenuItem
            // 
            this.changeTargetDirectoryToolStripMenuItem.Name = "changeTargetDirectoryToolStripMenuItem";
            this.changeTargetDirectoryToolStripMenuItem.Size = new System.Drawing.Size(328, 34);
            this.changeTargetDirectoryToolStripMenuItem.Text = "Change Target Directory";
            this.changeTargetDirectoryToolStripMenuItem.Click += new System.EventHandler(this.changeTargetDirectoryToolStripMenuItem_Click);
            // 
            // quitToolStripMenuItem
            // 
            this.quitToolStripMenuItem.Name = "quitToolStripMenuItem";
            this.quitToolStripMenuItem.Size = new System.Drawing.Size(328, 34);
            this.quitToolStripMenuItem.Text = "Quit";
            this.quitToolStripMenuItem.Click += new System.EventHandler(this.quitToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(141, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "FixIt Directory: ";
            // 
            // FixItTxtBox
            // 
            this.FixItTxtBox.Location = new System.Drawing.Point(161, 64);
            this.FixItTxtBox.Name = "FixItTxtBox";
            this.FixItTxtBox.Size = new System.Drawing.Size(435, 29);
            this.FixItTxtBox.TabIndex = 2;
            this.FixItTxtBox.Text = "C:\\Users\\Ian Ryu\\Desktop\\FixIt";
            // 
            // fileListView
            // 
            this.fileListView.LabelEdit = true;
            this.fileListView.Location = new System.Drawing.Point(198, 118);
            this.fileListView.Name = "fileListView";
            this.fileListView.Size = new System.Drawing.Size(908, 558);
            this.fileListView.TabIndex = 3;
            this.fileListView.UseCompatibleStateImageBehavior = false;
            // 
            // queryBtn
            // 
            this.queryBtn.Location = new System.Drawing.Point(687, 56);
            this.queryBtn.Name = "queryBtn";
            this.queryBtn.Size = new System.Drawing.Size(167, 47);
            this.queryBtn.TabIndex = 4;
            this.queryBtn.Text = "Query";
            this.queryBtn.UseVisualStyleBackColor = true;
            this.queryBtn.Click += new System.EventHandler(this.queryBtn_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(916, 56);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(180, 47);
            this.btnClear.TabIndex = 5;
            this.btnClear.Text = "Clear All";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // prefixTxtBox
            // 
            this.prefixTxtBox.Location = new System.Drawing.Point(18, 160);
            this.prefixTxtBox.Name = "prefixTxtBox";
            this.prefixTxtBox.Size = new System.Drawing.Size(174, 29);
            this.prefixTxtBox.TabIndex = 6;
            // 
            // bookLabel
            // 
            this.bookLabel.AutoSize = true;
            this.bookLabel.Location = new System.Drawing.Point(13, 132);
            this.bookLabel.Name = "bookLabel";
            this.bookLabel.Size = new System.Drawing.Size(131, 25);
            this.bookLabel.TabIndex = 7;
            this.bookLabel.Text = "Current Prefix";
            // 
            // btnApply
            // 
            this.btnApply.Location = new System.Drawing.Point(916, 699);
            this.btnApply.Name = "btnApply";
            this.btnApply.Size = new System.Drawing.Size(180, 54);
            this.btnApply.TabIndex = 8;
            this.btnApply.Text = "Apply";
            this.btnApply.UseVisualStyleBackColor = true;
            this.btnApply.Click += new System.EventHandler(this.btnApply_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(193, 714);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(151, 25);
            this.label2.TabIndex = 9;
            this.label2.Text = "Target Directory";
            // 
            // targetDirectoryTxtBox
            // 
            this.targetDirectoryTxtBox.Location = new System.Drawing.Point(368, 714);
            this.targetDirectoryTxtBox.Name = "targetDirectoryTxtBox";
            this.targetDirectoryTxtBox.Size = new System.Drawing.Size(486, 29);
            this.targetDirectoryTxtBox.TabIndex = 10;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1124, 765);
            this.Controls.Add(this.targetDirectoryTxtBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnApply);
            this.Controls.Add(this.bookLabel);
            this.Controls.Add(this.prefixTxtBox);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.queryBtn);
            this.Controls.Add(this.fileListView);
            this.Controls.Add(this.FixItTxtBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem changeFixItDirectoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem changeTargetDirectoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quitToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox FixItTxtBox;
        private System.Windows.Forms.ListView fileListView;
        private System.Windows.Forms.Button queryBtn;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.TextBox prefixTxtBox;
        private System.Windows.Forms.Label bookLabel;
        private System.Windows.Forms.Button btnApply;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox targetDirectoryTxtBox;
    }
}

