﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FileNameChangeApp
{
    public partial class Form1 : Form
    {
        private FolderBrowserDialog folderBrowserDialog;
        private string defaultFixItPath = "C:\\Users\\Ian Ryu\\Desktop\\FixIt";
        private string defaultTargetDirectory = "C:\\Users\\Ian Ryu\\Desktop\\FixIt_Empty";
        private List<string> fileNames;
        
        public Form1()
        {
            InitializeComponent();

            this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();

            // Do not allow the user to create new files via the FolderBrowserDialog.
            this.folderBrowserDialog.ShowNewFolderButton = false;
            
            // Set default directory for folderBrowserDialog
            this.folderBrowserDialog.SelectedPath = defaultFixItPath;
          
            FixItTxtBox.ReadOnly = true;
            targetDirectoryTxtBox.ReadOnly = true;
            targetDirectoryTxtBox.Text = defaultTargetDirectory;

            fileNames = new List<string>();

            fileListView.View = View.Details;
            fileListView.GridLines = true;         
        }

        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // nothing implemented
        }

        private void changeFixItDirectoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // open directory map and allow user to select directory
            if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
            {
                FixItTxtBox.Text = folderBrowserDialog.SelectedPath;
                fileListView.Clear();
                fileNames.Clear();
            }
            else
            {
                //MessageBox.Show("Canceled", "Directory Select Cancel",
                //MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void changeTargetDirectoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
            {
                targetDirectoryTxtBox.Text = folderBrowserDialog.SelectedPath;
                //fileListView.Clear();
                //fileNames.Clear();
            }
            else
            {
                //MessageBox.Show("Canceled", "Directory Select Cancel",
                //MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void quitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Quit the application
            if (MessageBox.Show("Do you really want to Close Application?", "Exit", MessageBoxButtons.YesNo) ==
                    System.Windows.Forms.DialogResult.Yes)
            {
                Application.Exit();
            }
            
        }

        private void queryBtn_Click(object sender, EventArgs e)
        {
            string currentDirectory = FixItTxtBox.Text;

            if (Directory.Exists(currentDirectory))
            {
                string[] files = Directory.GetFiles(currentDirectory);

                if (files.Length != 0)
                {
                    foreach (string fileName in files)
                    {
                        fileNames.Add(fileName);
                    }
                }
                else
                {
                    MessageBox.Show("There is no file in this directory", "Empty Directory",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                fileListView.BeginUpdate();
                fileListView.Columns.Add("New Names (Enter Names Here)", 235, HorizontalAlignment.Right);
                fileListView.Columns.Add("Scanned Names", 235, HorizontalAlignment.Center);
                
                string prefixName = "";
                // Add file names into ListView
                foreach(string fName in fileNames)
                {
                    int underScoreIndex = fName.IndexOf('_');
                    int dotIndex = fName.IndexOf('.');
                    int length = dotIndex - underScoreIndex -1;
                    string postfixName = fName.Substring(underScoreIndex+1, length);
                    ListViewItem listViewItem_scannedFileName = new ListViewItem(postfixName);
                    listViewItem_scannedFileName.SubItems.Add(postfixName);
                    fileListView.Items.Add(listViewItem_scannedFileName);

                    //ListViewItem listViewItem_newFileName = new ListViewItem(fName);
                    //listViewItem_newFileName.SubItems.Add(fName);
                    //fileListView.Items.Add(listViewItem_newFileName);

                    string[] segments = fName.Split('\\');
                    string lastSegment = segments[segments.Length-1];
                    int usIndex = lastSegment.IndexOf('_');
                    prefixName = lastSegment.Substring(0, usIndex+1);

                }
                
                fileListView.EndUpdate();
                prefixTxtBox.Text = prefixName;
            }
            else
            {
                MessageBox.Show("Invalid directory", "Folder Select Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            
            if (MessageBox.Show("Do you really want to clear?", "Clear", MessageBoxButtons.YesNo) ==
                    System.Windows.Forms.DialogResult.Yes)
            {
                fileListView.Clear();
                fileNames.Clear();
            }           
        }

        private void btnApply_Click(object sender, EventArgs e)
        {

        }
    }
}
